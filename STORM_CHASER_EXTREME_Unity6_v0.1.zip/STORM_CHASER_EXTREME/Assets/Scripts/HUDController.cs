
using UnityEngine;

public class HUDController : MonoBehaviour
{
    GUIStyle style, small, title;
    void OnGUI()
    {
        var gm=GameplayManager.Instance;if(gm==null||gm.vehicle==null)return;
        if(style==null){style=new GUIStyle(GUI.skin.label){fontSize=18,fontStyle=FontStyle.Bold,normal={textColor=Color.white}};small=new GUIStyle(style){fontSize=13};title=new GUIStyle(style){fontSize=22};}
        GUI.color=new Color(.025f,.04f,.055f,.78f);GUI.Box(new Rect(18,18,285,128),"");GUI.color=Color.white;
        GUI.Label(new Rect(32,24,260,28),"STORM CHASER EXTREME",title);
        GUI.Label(new Rect(32,57,250,24),$"CHACO  |  {gm.vehicle.SpeedKmh:000} km/h",style);
        GUI.Label(new Rect(32,83,250,22),$"DIESEL  {gm.vehicle.fuel:00.0}%   ARMOR: NOMINAL",small);
        GUI.Label(new Rect(32,105,250,22),$"SKIRTS: {(gm.vehicle.skirtsDeployed?"DEPLOYED":"RETRACTED")}   ANCHORS: {(gm.vehicle.anchorsDeployed?"SET":"STOWED")}",small);
        GUI.Label(new Rect(20,Screen.height-42,800,28),"WASD DRIVE  |  E EXIT  |  F SKIRTS  |  G ANCHORS  |  C CAMERAS  |  R RADAR",small);
        GUI.color=new Color(.025f,.04f,.055f,.78f);GUI.Box(new Rect(Screen.width-300,18,282,190),"");GUI.color=Color.white;
        GUI.Label(new Rect(Screen.width-285,25,260,26),"LIVE STORM TELEMETRY",style);
        GUI.Label(new Rect(Screen.width-285,55,260,20),"SUPERCELL  •  TORNADO WARNING",small);
        GUI.Label(new Rect(Screen.width-285,78,260,20),"EST. INTENSITY: EF2–EF3 (SIM)",small);
        GUI.Label(new Rect(Screen.width-285,100,260,20),"RADIAL VELOCITY: ±42 m/s",small);
        GUI.Label(new Rect(Screen.width-285,122,260,20),"HOOK ECHO: DETECTED",small);
        GUI.Label(new Rect(Screen.width-285,144,260,20),"MESOCYCLONE: TRACKED",small);
        GUI.Label(new Rect(Screen.width-285,166,260,20),"CREDITS: $2,500",small);
        if(gm.radarVisible)DrawRadar();
    }
    void DrawRadar()
    {
        float x=Screen.width-205,y=Screen.height-205,r=82;
        GUI.color=new Color(.02f,.08f,.08f,.86f);GUI.DrawTexture(new Rect(x-r-12,y-r-12,2*r+24,2*r+24),Texture2D.whiteTexture);
        GUI.color=new Color(.12f,.55f,.48f,.8f);
        for(int i=1;i<=3;i++)GUI.Box(new Rect(x-r*i/3,y-r*i/3,2*r*i/3,2*r*i/3),"");
        GUI.color=new Color(.3f,.9f,.45f,.9f);GUI.DrawTexture(new Rect(x-4,y-4,8,8),Texture2D.whiteTexture);
        GUI.color=new Color(.9f,.22f,.12f,.95f);GUI.DrawTexture(new Rect(x+34,y-28,30,16),Texture2D.whiteTexture);
        GUI.color=new Color(.2f,.7f,.95f,.9f);GUI.Label(new Rect(x-r,y+r+8,2*r,20),"DOPPLER SIM • REFLECTIVITY",small);
        GUI.color=Color.white;
    }
}
