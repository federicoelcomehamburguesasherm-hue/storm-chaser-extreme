
using UnityEngine;

public class WorldBuilder : MonoBehaviour
{
    Material MakeMat(string name, Color c, float metallic=0, float smooth=0.25f)
    {
        var m = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (m.shader == null) m = new Material(Shader.Find("Standard"));
        m.name=name; m.color=c; m.SetFloat("_Metallic",metallic); m.SetFloat("_Smoothness",smooth); return m;
    }
    void Start()
    {
        var grass=MakeMat("Prairie | dry grass",new Color(.25f,.29f,.20f));
        var asphalt=MakeMat("Road | weathered asphalt",new Color(.075f,.08f,.085f));
        var yellow=MakeMat("Road markings",new Color(.88f,.69f,.24f));
        var concrete=MakeMat("Concrete",new Color(.34f,.35f,.34f));
        var red=MakeMat("Barn red",new Color(.28f,.095f,.065f));
        var ground=GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name="Prairie terrain"; ground.transform.position=new Vector3(0,-.15f,0); ground.transform.localScale=new Vector3(65,1,65); ground.GetComponent<Renderer>().material=grass;
        Cube("County highway",new Vector3(0,.02f,0),new Vector3(12,.12f,520),asphalt);
        for(int z=-240;z<=240;z+=24) Cube("Yellow center dash",new Vector3(0,.09f,z),new Vector3(.22f,.025f,10),yellow);
        for(int i=0;i<30;i++)
        {
            float x=(i%2==0?1:-1)*Random.Range(25,100), z=Random.Range(-230,230);
            Cube("Low prairie building",new Vector3(x,2,z),new Vector3(Random.Range(8,18),4,Random.Range(8,16)),i%3==0?red:concrete);
            Cube("Roof",new Vector3(x,4.5f,z),new Vector3(10,.8f,11),asphalt);
        }
        for(int i=0;i<80;i++)
        {
            float x=Random.Range(-250,250),z=Random.Range(-250,250);
            if(Mathf.Abs(x)<18) continue;
            var b=GameObject.CreatePrimitive(PrimitiveType.Cube);
            b.name="Prairie scrub"; b.transform.position=new Vector3(x,.3f,z); b.transform.localScale=new Vector3(Random.Range(.5f,2f),Random.Range(.4f,1.5f),Random.Range(.5f,2f)); b.GetComponent<Renderer>().material=grass;
        }
    }
    void Cube(string n,Vector3 p,Vector3 s,Material m){var o=GameObject.CreatePrimitive(PrimitiveType.Cube);o.name=n;o.transform.position=p;o.transform.localScale=s;o.GetComponent<Renderer>().material=m;}
}
