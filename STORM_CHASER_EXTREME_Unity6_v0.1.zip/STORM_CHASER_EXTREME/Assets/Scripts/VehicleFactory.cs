
using UnityEngine;

public static class VehicleFactory
{
    static Material Mat(string n,Color c,float metal=0,float smooth=.35f)
    {
        var s=Shader.Find("Universal Render Pipeline/Lit"); if(s==null)s=Shader.Find("Standard");
        var m=new Material(s){name=n,color=c};m.SetFloat("_Metallic",metal);m.SetFloat("_Smoothness",smooth);return m;
    }
    static GameObject Part(string n,Transform p,Vector3 pos,Vector3 scale,Material m,PrimitiveType type=PrimitiveType.Cube)
    {
        var o=GameObject.CreatePrimitive(type);o.name=n;o.transform.SetParent(p,false);o.transform.localPosition=pos;o.transform.localScale=scale;o.GetComponent<Renderer>().material=m;return o;
    }
    public static VehicleController Create(Vector3 pos)
    {
        var root=new GameObject("CHACO | Storm Interceptor");
        root.transform.position=pos;
        var body=Mat("CHACO | graphite ceramic armor",new Color(.16f,.19f,.21f),.72f,.72f);
        var dark=Mat("Rubber / underbody",new Color(.025f,.03f,.032f),.05f,.2f);
        var glass=Mat("Laminated ballistic glass",new Color(.10f,.22f,.27f),.25f,.9f);
        var metal=Mat("Brushed steel",new Color(.43f,.47f,.49f),.85f,.75f);
        var orange=Mat("Safety amber",new Color(1f,.34f,.035f),.2f,.65f);
        Part("Armored monocoque",root.transform,new Vector3(0,1.25f,0),new Vector3(2.45f,1.15f,4.65f),body);
        Part("Sloped front armor",root.transform,new Vector3(0,1.78f,1.55f),new Vector3(2.25f,.78f,1.45f),body).transform.localRotation=Quaternion.Euler(18,0,0);
        Part("Cabin roof",root.transform,new Vector3(0,2.42f,-.25f),new Vector3(2.2f,.24f,2.2f),body);
        Part("Front reinforced windshield",root.transform,new Vector3(0,2.03f,.83f),new Vector3(1.9f,.08f,.92f),glass).transform.localRotation=Quaternion.Euler(22,0,0);
        Part("Left side ballistic window",root.transform,new Vector3(-1.235f,2.02f,-.15f),new Vector3(.04f,.62f,1.25f),glass);
        Part("Right side ballistic window",root.transform,new Vector3(1.235f,2.02f,-.15f),new Vector3(.04f,.62f,1.25f),glass);
        Part("Rear window",root.transform,new Vector3(0,2.02f,-1.35f),new Vector3(1.8f,.55f,.05f),glass);
        Part("Front steel bumper",root.transform,new Vector3(0,.78f,2.42f),new Vector3(2.65f,.32f,.35f),metal);
        Part("Rear steel bumper",root.transform,new Vector3(0,.78f,-2.42f),new Vector3(2.65f,.32f,.35f),metal);
        Part("Roof Doppler instrument pod",root.transform,new Vector3(0,2.72f,-.45f),new Vector3(.72f,.28f,.72f),metal,PrimitiveType.Cylinder);
        Part("Roof sensor mast",root.transform,new Vector3(0,3.02f,-1.05f),new Vector3(.07f,.48f,.07f),metal);
        Part("Meteorological sensor",root.transform,new Vector3(0,3.28f,-1.05f),new Vector3(.42f,.12f,.42f),orange,PrimitiveType.Sphere);
        Part("Front lightbar",root.transform,new Vector3(0,2.58f,.5f),new Vector3(1.55f,.12f,.2f),orange);
        var rb=root.AddComponent<Rigidbody>();rb.mass=5200;rb.drag=.08f;
        var vc=root.AddComponent<VehicleController>();
        Vector3[] wp={new Vector3(-1.12f,.62f,1.48f),new Vector3(1.12f,.62f,1.48f),new Vector3(-1.12f,.62f,-1.48f),new Vector3(1.12f,.62f,-1.48f)};
        for(int i=0;i<4;i++)
        {
            var wcObj=new GameObject("WheelCollider "+i);wcObj.transform.SetParent(root.transform,false);wcObj.transform.localPosition=wp[i];
            var wc=wcObj.AddComponent<WheelCollider>();wc.radius=.52f;wc.suspensionDistance=.28f;wc.mass=65;wc.wheelDampingRate=1.2f;
            var spring=wc.suspensionSpring;spring.spring=42000;spring.damper=5200;spring.targetPosition=.5f;wc.suspensionSpring=spring;
            vc.wheels[i]=wc;
            var wheel=Part("All-terrain tire",root.transform,wp[i],new Vector3(.42f,1.04f,1.04f),dark,PrimitiveType.Cylinder);wheel.transform.localRotation=Quaternion.Euler(0,0,90);vc.wheelMeshes[i]=wheel.transform;
            Part("Wheel hub",wheel.transform,new Vector3(0,0,-.08f),new Vector3(1.02f,.28f,.28f),metal,PrimitiveType.Cylinder);
        }
        vc.skirts=new Transform[4];vc.anchors=new Transform[4];
        Vector3[] sides={new Vector3(-1.26f,.1f,0),new Vector3(1.26f,.1f,0),new Vector3(0,.1f,2.18f),new Vector3(0,.1f,-2.18f)};
        for(int i=0;i<4;i++)
        {
            var sk=Part("Hydraulic storm skirt "+i,root.transform,sides[i],i<2?new Vector3(.12f,.12f,3.3f):new Vector3(1.9f,.12f,.12f),metal);vc.skirts[i]=sk.transform;
            var an=Part("Deployable ground anchor "+i,root.transform,new Vector3(sides[i].x*1.03f,.1f,sides[i].z),new Vector3(.12f,.36f,.12f),orange);vc.anchors[i]=an.transform;
        }
        return vc;
    }
}
