
using UnityEngine;

public class StormSystem : MonoBehaviour
{
    public Transform tornado;
    public float intensity=.82f;
    Material funnelMat, cloudMat;
    float t;
    void Start()
    {
        funnelMat=Make("Funnel | turbulent slate",new Color(.19f,.21f,.22f,.88f),true);
        cloudMat=Make("Supercell | deep storm cloud",new Color(.105f,.12f,.15f,.94f),true);
        var cloud=new GameObject("Rotating supercell mesocyclone");cloud.transform.position=new Vector3(55,37,95);
        for(int i=0;i<7;i++)
        {
            var c=GameObject.CreatePrimitive(PrimitiveType.Sphere);c.name="Layered cumulonimbus mass";c.transform.SetParent(cloud.transform);
            c.transform.localPosition=new Vector3((i-3)*7,Random.Range(-2f,3f),Random.Range(-3f,3f));
            c.transform.localScale=new Vector3(18,10,16);c.GetComponent<Renderer>().material=cloudMat;Destroy(c.GetComponent<Collider>());
        }
        tornado=new GameObject("Dynamic tornado").transform;tornado.position=new Vector3(55,0,95);
        BuildFunnel();
        var debris=new GameObject("Tornado debris field");debris.transform.position=tornado.position;
        var ps=debris.AddComponent<ParticleSystem>();var main=ps.main;main.startLifetime=4;main.startSpeed=8;main.startSize=.35f;main.maxParticles=500;main.startColor=new Color(.35f,.31f,.25f);
        var emission=ps.emission;emission.rateOverTime=75;
        var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Cone;shape.angle=35;shape.radius=8;
        var vel=ps.velocityOverLifetime;vel.enabled=true;vel.orbitalY=8;ps.Play();
        var rain=new GameObject("Heavy rain curtain");rain.transform.position=new Vector3(45,25,85);
        var rp=rain.AddComponent<ParticleSystem>();var rm=rp.main;rm.startLifetime=2;rm.startSpeed=28;rm.startSize=.06f;rm.startColor=new Color(.6f,.68f,.75f,.55f);var re=rp.emission;re.rateOverTime=1800;var rs=rp.shape;rs.shapeType=ParticleSystemShapeType.Box;rs.scale=new Vector3(80,2,55);rp.Play();
    }
    Material Make(string n,Color c,bool transparent)
    {
        var s=Shader.Find("Universal Render Pipeline/Lit");if(s==null)s=Shader.Find("Standard");
        var m=new Material(s){name=n,color=c};if(transparent){m.SetFloat("_Surface",1);m.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.SrcAlpha);m.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);m.SetInt("_ZWrite",0);m.renderQueue=3000;}return m;
    }
    void BuildFunnel()
    {
        int rings=36, sides=24;var mesh=new Mesh();var v=new Vector3[rings*sides];var tri=new int[(rings-1)*sides*6];
        for(int y=0;y<rings;y++){float f=y/(float)(rings-1);float radius=Mathf.Lerp(2.2f,15f,f)*(.9f+.1f*Mathf.Sin(f*18));for(int s=0;s<sides;s++){float a=s*Mathf.PI*2/sides;v[y*sides+s]=new Vector3(Mathf.Cos(a)*radius,f*42,Mathf.Sin(a)*radius);}}
        int k=0;for(int y=0;y<rings-1;y++)for(int s=0;s<sides;s++){int a=y*sides+s,b=y*sides+(s+1)%sides,c=(y+1)*sides+s,d=(y+1)*sides+(s+1)%sides;tri[k++]=a;tri[k++]=c;tri[k++]=b;tri[k++]=b;tri[k++]=c;tri[k++]=d;}
        mesh.vertices=v;mesh.triangles=tri;mesh.RecalculateNormals();
        var go=new GameObject("Procedural rotating condensation funnel");go.transform.SetParent(tornado,false);go.transform.localPosition=Vector3.zero;
        go.AddComponent<MeshFilter>().mesh=mesh;go.AddComponent<MeshRenderer>().material=funnelMat;
    }
    void Update(){t+=Time.deltaTime;if(tornado){tornado.position+=new Vector3(Mathf.Sin(t*.07f)*.018f,0,Mathf.Cos(t*.05f)*.025f);tornado.Rotate(Vector3.up,42*Time.deltaTime);}}
}
