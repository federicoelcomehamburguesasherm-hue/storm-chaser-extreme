
using UnityEngine;
using UnityEngine.Rendering;

public class RuntimeBootstrap : MonoBehaviour
{
    void Start()
    {
        Application.targetFrameRate = 90;
        QualitySettings.vSyncCount = 0;
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.0018f;
        RenderSettings.fogColor = new Color(0.20f, 0.23f, 0.27f);
        CreateLighting();
        GameObject world = new GameObject("SCE_World");
        world.AddComponent<WorldBuilder>();
        GameObject storm = new GameObject("SCE_StormSystem");
        storm.AddComponent<StormSystem>();
        GameObject player = new GameObject("SCE_Gameplay");
        player.AddComponent<GameplayManager>();
        player.AddComponent<HUDController>();
    }

    void CreateLighting()
    {
        var sun = new GameObject("Stormy afternoon sun").AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.15f;
        sun.color = new Color(0.72f, 0.78f, 0.86f);
        sun.transform.rotation = Quaternion.Euler(32, -28, 0);
        sun.shadows = LightShadows.Soft;
    }
}
