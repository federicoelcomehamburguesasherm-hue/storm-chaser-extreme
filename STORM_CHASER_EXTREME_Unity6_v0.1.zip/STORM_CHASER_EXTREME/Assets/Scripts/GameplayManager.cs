
using UnityEngine;

public class GameplayManager : MonoBehaviour
{
    public static GameplayManager Instance;
    public VehicleController vehicle;
    public Transform player;
    public Camera activeCamera;
    public bool inVehicle=true, radarVisible=true;
    int cameraMode=0;
    readonly Vector3[] cameraOffsets={new Vector3(0,2.03f,.15f),new Vector3(.55f,2.03f,.15f),new Vector3(0,5,-8),new Vector3(0,2,-5),new Vector3(0,3.8f,-.5f)};
    void Start()
    {
        Instance=this;vehicle=VehicleFactory.Create(new Vector3(0,1,0));
        var p=GameObject.CreatePrimitive(PrimitiveType.Capsule);p.name="Storm chaser character";p.transform.position=new Vector3(2,1,0);p.transform.localScale=new Vector3(.7f,1.8f,.7f);p.GetComponent<Renderer>().material=new Material(Shader.Find("Standard")){color=new Color(.12f,.16f,.2f)};player=p.transform;p.SetActive(false);
        var cam=new GameObject("Player camera").AddComponent<Camera>();cam.fieldOfView=72;activeCamera=cam;cam.transform.SetParent(vehicle.transform);cam.transform.localPosition=cameraOffsets[0];cam.transform.localRotation=Quaternion.identity;
        var listener=cam.gameObject.AddComponent<AudioListener>();
    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.E))ToggleVehicle();
        if(Input.GetKeyDown(KeyCode.C)&&inVehicle){cameraMode=(cameraMode+1)%cameraOffsets.Length;activeCamera.transform.localPosition=cameraOffsets[cameraMode];activeCamera.transform.localRotation=cameraMode==2?Quaternion.Euler(12,0,0):Quaternion.identity;}
        if(Input.GetKeyDown(KeyCode.F)&&inVehicle)vehicle.ToggleSkirts();
        if(Input.GetKeyDown(KeyCode.G)&&inVehicle)vehicle.ToggleAnchors();
        if(Input.GetKeyDown(KeyCode.R))radarVisible=!radarVisible;
        if(!inVehicle)Walk();
    }
    void ToggleVehicle()
    {
        inVehicle=!inVehicle;
        if(inVehicle){player.gameObject.SetActive(false);activeCamera.transform.SetParent(vehicle.transform);activeCamera.transform.localPosition=cameraOffsets[cameraMode];activeCamera.transform.localRotation=Quaternion.identity;}
        else{player.position=vehicle.transform.position+vehicle.transform.right*2.5f+Vector3.up*.1f;player.gameObject.SetActive(true);activeCamera.transform.SetParent(player);activeCamera.transform.localPosition=new Vector3(0,1.55f,0);activeCamera.transform.localRotation=Quaternion.identity;}
    }
    void Walk()
    {
        float x=Input.GetAxis("Horizontal"),z=Input.GetAxis("Vertical");float speed=Input.GetKey(KeyCode.LeftShift)?8:4;
        player.Translate(new Vector3(x,0,z)*speed*Time.deltaTime,Space.Self);
        float mx=Input.GetAxis("Mouse X"),my=Input.GetAxis("Mouse Y");player.Rotate(0,mx*2,0);
        activeCamera.transform.localRotation=Quaternion.Euler(Mathf.Clamp(activeCamera.transform.localEulerAngles.x-my*2,-65,65),0,0);
    }
}
