
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class VehicleController : MonoBehaviour
{
    public WheelCollider[] wheels = new WheelCollider[4];
    public Transform[] wheelMeshes = new Transform[4];
    public float motorTorque=620f, brakeTorque=2800f, maxSteer=27f, fuel=100f;
    public bool skirtsDeployed, anchorsDeployed;
    public Transform[] skirts, anchors;
    Rigidbody rb;
    void Awake(){rb=GetComponent<Rigidbody>();rb.mass=5200;rb.centerOfMass=new Vector3(0,-.65f,0);rb.interpolation=RigidbodyInterpolation.Interpolate;}
    void FixedUpdate()
    {
        float throttle=Input.GetAxis("Vertical"), steer=Input.GetAxis("Horizontal");
        bool brake=Input.GetKey(KeyCode.Space);
        for(int i=0;i<wheels.Length;i++)
        {
            if(wheels[i]==null)continue;
            if(i<2) wheels[i].steerAngle=steer*maxSteer;
            wheels[i].motorTorque=(i>=2?throttle*motorTorque:throttle*motorTorque*.12f);
            wheels[i].brakeTorque=brake?brakeTorque:0;
            if(wheelMeshes[i]){wheels[i].GetWorldPose(out var p,out var q);wheelMeshes[i].SetPositionAndRotation(p,q);}
        }
        if(Mathf.Abs(throttle)>.05f && fuel>0) fuel=Mathf.Max(0,fuel-Time.fixedDeltaTime*.018f*Mathf.Abs(throttle));
        if(anchorsDeployed){rb.AddForce(-transform.up*25000f);rb.angularVelocity*=.92f;}
    }
    public float SpeedKmh=>rb.velocity.magnitude*3.6f;
    public void ToggleSkirts()
    {
        skirtsDeployed=!skirtsDeployed;
        foreach(var t in skirts) if(t) t.localPosition=new Vector3(t.localPosition.x,skirtsDeployed?-.72f:-.18f,t.localPosition.z);
    }
    public void ToggleAnchors()
    {
        anchorsDeployed=!anchorsDeployed;
        foreach(var t in anchors) if(t) t.localPosition=new Vector3(t.localPosition.x,anchorsDeployed?-.95f:-.18f,t.localPosition.z);
    }
}
