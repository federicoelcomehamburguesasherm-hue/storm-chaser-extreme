
# STORM CHASER EXTREME — Unity 6 playable vertical slice

This is a real Unity project scaffold for **Unity 6 (6000.0+)**. It contains a runtime-generated 3D test world, the original CHACO interceptor, WheelCollider driving, deployable hydraulic skirts and ground anchors, a procedural supercell/tornado, a simulated Doppler radar HUD, camera modes, and PC controls.

## Open and run
1. Install Unity Hub and Unity 6 (6000.0 LTS or newer).
2. Add this folder in Unity Hub (`STORM_CHASER_EXTREME`).
3. Open the project. Open `Assets/Scenes/Main.unity`.
4. Press Play. The scene bootstraps its environment and gameplay at runtime.

No external assets are required. Models are procedural meshes built by the scripts; this avoids missing asset links and makes the first slice immediately inspectable.

## Controls (PC)
- W / S: throttle / reverse
- A / D: steering
- Space: handbrake
- E: enter / exit vehicle
- F: deploy / retract hydraulic skirts
- G: deploy / retract ground anchors (spikes)
- C: cycle cameras (driver, passenger, exterior, rear, roof)
- R: toggle radar display
- Mouse: look around while on foot
- Shift: run

## What is implemented
- Procedural 3D terrain, road, roadside structures and storm environment.
- CHACO interceptor bodywork with wheels, glass, roof instruments, bumpers and lighting.
- Rigidbody + WheelCollider vehicle dynamics, steering, braking and basic damage exposure.
- Functional skirt and anchor deployment animations.
- Procedural tornado funnel and rotating debris particles; supercell cloud structure and rain.
- Radar-like reflectivity/radial velocity visualization derived from the in-game storm position and intensity.
- Multiple vehicle camera positions and basic on-foot character mode.
- Runtime HUD with speed, fuel, vehicle state, storm status and credits.

## Important scope / honest limitations
This is **Version 0.1 — a playable vertical slice**, not a finished AAA production. The tornado, supercell, radar and vehicle are game simulations, not validated meteorological models or operational Doppler products. The world is a compact test region rather than a full open-world map. Character animation, photogrammetry-grade assets, production audio, missions, saving, economy balancing, Android touch controls and final platform optimization remain future production work.

For best results use a PC with a dedicated GPU. Android is included as a target platform in the project setup, but this first slice still needs touch UI and mobile performance profiling before it is device-ready.
